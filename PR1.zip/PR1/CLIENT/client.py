from client_gui import FileClientApp

app = FileClientApp()
app.mainloop()
